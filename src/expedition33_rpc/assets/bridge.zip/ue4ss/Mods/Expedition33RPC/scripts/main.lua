print("[Expedition33RPC] Discord Rich Presence Bridge Mod Loaded!\n")

local temp_dir = os.getenv("TEMP") or "C:\\Windows\\Temp"
local status_path = temp_dir .. "\\expedition33_status.json"
local tmp_path = status_path .. ".tmp"

local current_combat_state = false
local current_enemy_name = ""
local current_zone = ""
local current_checkpoint = ""
local tick_counter = 0

local function clean_enemy_bp_name(raw)
    if not raw or raw == "" then return "" end

    local name = raw
    name = string.gsub(name, "_C_%d+", "")
    name = string.gsub(name, "_C$", "")
    name = string.gsub(name, "_%d+$", "")

    local prefixes = {
        "BP_Enemy_Battle_",
        "BP_EnemyBattle_",
        "BP_jRPG_EnemyBattle_",
        "BP_jRPG_EnemyWorld_",
        "BP_jRPG_Enemy_",
        "BP_jRPG_Boss_",
        "BP_EnemyWorld_",
        "BP_Enemy_",
        "BP_Boss_",
        "BP_Minion_",
        "BP_",
        "Default__",
    }
    for _, p in ipairs(prefixes) do
        if string.sub(name, 1, #p) == p then
            name = string.sub(name, #p + 1)
            break
        end
    end

    name = string.gsub(name, "_[A-Za-z]$", "")
    name = string.gsub(name, "_%d+$", "")
    name = string.gsub(name, "_", " ")
    name = string.gsub(name, "(%l)(%u)", "%1 %2")
    name = string.gsub(name, "(%u)(%u%l)", "%1 %2")

    return (string.match(name, "^%s*(.-)%s*$") or name)
end

local function clean_level_name(raw)
    if not raw or raw == "" then return "" end

    local name = raw
    name = string.gsub(name, "_C$", "")
    name = string.gsub(name, "_%d+$", "")

    local prefixes = {
        "Level_Side_",
        "Level_Main_",
        "Level_Small_",
        "Level_WorldMap_",
        "SideLevel_",
        "MainLevel_",
        "SmallLevel_",
        "Level_",
    }
    for _, p in ipairs(prefixes) do
        if string.sub(name, 1, #p) == p then
            name = string.sub(name, #p + 1)
            break
        end
    end

    name = string.gsub(name, "_V%d+$", "")
    name = string.gsub(name, "_", " ")
    name = string.gsub(name, "(%l)(%u)", "%1 %2")
    name = string.gsub(name, "(%u)(%u%l)", "%1 %2")
    name = string.match(name, "^%s*(.-)%s*$") or name
    if name == "Main" or string.find(string.lower(raw), "worldmap") then
        return "The Continent"
    end
    return name
end

local function format_enemy_summary(enemy_list)
    if not enemy_list or #enemy_list == 0 then
        return ""
    end

    local counts = {}
    local order = {}
    for _, name in ipairs(enemy_list) do
        if name and name ~= "" then
            if not counts[name] then
                counts[name] = 0
                table.insert(order, name)
            end
            counts[name] = counts[name] + 1
        end
    end

    if #order == 0 then
        return ""
    end

    local parts = {}
    for _, name in ipairs(order) do
        local c = counts[name]
        if c > 1 then
            table.insert(parts, string.format("%s x%d", name, c))
        else
            table.insert(parts, name)
        end
    end

    local summary = table.concat(parts, ", ")
    if #summary > 50 then
        if #order > 1 then
            local first = parts[1]
            local remaining = 0
            for i = 2, #order do
                remaining = remaining + counts[order[i]]
            end
            summary = string.format("%s (+%d)", first, remaining)
        else
            summary = string.sub(summary, 1, 47) .. "..."
        end
    end

    return summary
end

local function write_status(in_combat, enemy_name, zone, checkpoint)
    enemy_name = enemy_name or ""
    zone = zone or ""
    checkpoint = checkpoint or current_checkpoint or ""
    local escaped_enemy = string.gsub(enemy_name, '"', '\\"')
    local escaped_zone = string.gsub(zone, '"', '\\"')
    local escaped_checkpoint = string.gsub(checkpoint, '"', '\\"')
    local f = io.open(tmp_path, "w")
    if f then
        f:write(string.format('{"in_combat": %s, "enemy_name": "%s", "zone": "%s", "checkpoint": "%s", "timestamp": %d}\n',
            in_combat and "true" or "false",
            escaped_enemy,
            escaped_zone,
            escaped_checkpoint,
            os.time()))
        f:close()
        os.remove(status_path)
        os.rename(tmp_path, status_path)
    end
end

-- Scan UMG widget properties for on-screen text
local function scan_widget_text(w)
    if not w or not w:IsValid() then return nil end

    -- 1. Try known property names first
    local candidate_props = {
        "LevelName", "Text_LevelName", "TextBlock_LevelName",
        "LevelTitle", "Text_LevelTitle", "TextBlock_LevelTitle",
        "ZoneName", "Text_ZoneName", "CurrentLevel", "LevelText",
        "Title", "Text_Title", "Name", "Text_Name"
    }
    for _, pname in ipairs(candidate_props) do
        local ok, val = pcall(function() return w[pname] end)
        if ok and val then
            local ok_gt, txt = pcall(function() return val:GetText():ToString() end)
            if ok_gt and txt and txt ~= "" and txt ~= "None" and not string.find(txt, "<") and #txt > 1 and #txt < 60 then
                return txt
            end
            local ok_ts, s = pcall(function() return val:ToString() end)
            if ok_ts and s and s ~= "" and s ~= "None" and not string.find(s, "<") and #s > 1 and #s < 60 then
                if not string.find(s, "/") and not string.find(s, "BP_") and not string.find(s, "_C") then
                    return s
                end
            end
        end
    end

    -- 2. Reflection scan on PropertyLink
    local ok_cls, cls = pcall(function() return w:GetClass() end)
    if ok_cls and cls and cls:IsValid() then
        local prop = cls.PropertyLink
        while prop and prop:IsValid() do
            local pname = prop:GetFName():ToString()
            if string.find(pname, "Name") or string.find(pname, "Title") or string.find(pname, "Text") or string.find(pname, "Zone") then
                local ok_v, val = pcall(function() return w[pname] end)
                if ok_v and val then
                    local ok_gt, txt = pcall(function() return val:GetText():ToString() end)
                    if ok_gt and txt and txt ~= "" and txt ~= "None" and not string.find(txt, "<") and #txt > 1 and #txt < 60 then
                        return txt
                    end
                    local ok_ts, s = pcall(function() return val:ToString() end)
                    if ok_ts and s and s ~= "" and s ~= "None" and not string.find(s, "<") and #s > 1 and #s < 60 then
                        if not string.find(s, "/") and not string.find(s, "BP_") and not string.find(s, "_C") then
                            return s
                        end
                    end
                end
            end
            prop = prop.PropertyLinkNext
        end
    end

    return nil
end

-- Zone resolution on Game Thread
local function resolve_dynamic_screen_zone()
    local zone_found = nil

    -- 1. Try to read from active on-screen HUD widgets
    local widget_classes = {
        "WBP_LevelNameWidget_C",
        "WBP_WorldMapLevelNameContainer_C",
        "WBP_HUD_LevelNameAnnounce_C",
        "WBP_HUD_LevelNameAnnounceQueue_C",
        "WBP_Exploration_HUD_C",
        "WBP_FlyMode_C",
    }
    for _, wclass in ipairs(widget_classes) do
        local widgets = nil
        pcall(function() widgets = FindAllOf(wclass) end)
        if widgets then
            for _, w in ipairs(widgets) do
                if w and w:IsValid() then
                    local txt = scan_widget_text(w)
                    if txt and txt ~= "" then
                        zone_found = txt
                        print(string.format("[Expedition33RPC] Dynamic Zone from %s: '%s'\n", wclass, zone_found))
                        break
                    end
                end
            end
        end
        if zone_found then break end
    end

    -- 2. Fallback to clean level name from UGameplayStatics / UWorld
    if not zone_found then
        local raw_level = ""
        pcall(function()
            local UEHelpers = require("UEHelpers")
            local world = UEHelpers.GetWorld()
            if world and world:IsValid() then
                local statics = StaticFindObject("/Script/Engine.Default__GameplayStatics")
                if statics and statics:IsValid() and type(statics.GetCurrentLevelName) == "function" then
                    local lvl = statics:GetCurrentLevelName(world, true)
                    if lvl then
                        local s = lvl:ToString()
                        if s and s ~= "" and s ~= "None" then
                            raw_level = s
                        end
                    end
                end
                if raw_level == "" then
                    local plevel = world.PersistentLevel
                    if plevel and plevel:IsValid() then
                        local pouter = plevel:GetOuter()
                        if pouter and pouter:IsValid() then
                            local s = pouter:GetFName():ToString()
                            if s and s ~= "" and s ~= "None" then
                                raw_level = s
                            end
                        end
                    end
                end
            end
        end)

        if raw_level ~= "" then
            zone_found = clean_level_name(raw_level)
        end
    end

    return zone_found
end

-- Checkpoint / SavePoint resolution on Game Thread
local function resolve_dynamic_checkpoint()
    local cp = nil
    pcall(function()
        local menu = FindFirstOf("WBP_SavePointMenu_C")
        if menu and menu:IsValid() then
            local candidate_names = {
                "Text_Subzone", "Text_SubzoneName", "Text_Checkpoint",
                "Text_AreaName", "Text_Location", "SubzoneName",
                "Text_Zone", "ZoneText", "SubzoneText", "Text_SavePointName"
            }
            for _, name in ipairs(candidate_names) do
                local ok, prop = pcall(function() return menu[name] end)
                if ok and prop and prop:IsValid() then
                    local ok_gt, t = pcall(function() return prop:GetText():ToString() end)
                    if ok_gt and t and t ~= "" and t ~= "None" and not string.find(t, "<") and #t > 1 and #t < 60 then
                        cp = t
                        break
                    end
                end
            end
        end
    end)
    return cp
end

-- Inspect active enemies on Game Thread
local function inspect_active_enemies()
    local enemy_names = {}
    local bm = FindFirstOf("AC_jRPG_BattleManager_C")
    if not bm or not bm:IsValid() then return "" end
    if not bm.Enemies or not bm.Enemies:IsValid() then return "" end

    local count = bm.Enemies:GetArrayNum()
    for i = 1, count do
        pcall(function()
            local elem = bm.Enemies[i]
            local actor = elem
            if actor and type(actor.get) == "function" then
                actor = actor:get()
            end
            if actor and actor:IsValid() then
                local ename = ""
                -- 1. Try CharacterName (FText) if valid text
                pcall(function()
                    if actor.CharacterName and type(actor.CharacterName.ToString) == "function" then
                        local s = actor.CharacterName:ToString()
                        if s and s ~= "" and s ~= "None" and not string.find(s, "<") and not string.find(s, "UObject:") and not string.find(s, "0x") and #s > 1 and #s < 50 then
                            ename = s
                        end
                    end
                end)

                -- 2. Fallback to clean blueprint name (class first, then actor FName)
                if ename == "" then
                    pcall(function()
                        local cls = actor:GetClass()
                        if cls and cls:IsValid() then
                            local raw = cls:GetFName():ToString()
                            ename = clean_enemy_bp_name(raw)
                        end
                    end)
                end

                if ename == "" then
                    pcall(function()
                        local raw = actor:GetFName():ToString()
                        ename = clean_enemy_bp_name(raw)
                    end)
                end

                if ename ~= "" and ename ~= "None" and not string.find(ename, "UObject:") and not string.find(ename, "0x") then
                    table.insert(enemy_names, ename)
                end
            end
        end)
    end

    return format_enemy_summary(enemy_names)
end

-- Initialize initial status on Game Thread
ExecuteInGameThread(function()
    local z = resolve_dynamic_screen_zone()
    if z and z ~= "" then
        current_zone = z
        print(string.format("[Expedition33RPC] Initial Zone: '%s'\n", current_zone))
    end
    write_status(false, "", current_zone)
end)

-- Hook map loads to update zone immediately
RegisterLoadMapPostHook(function(Engine, World)
    ExecuteInGameThread(function()
        local z = resolve_dynamic_screen_zone()
        if z and z ~= "" then
            current_zone = z
            print(string.format("[Expedition33RPC] Zone on Map Load: '%s'\n", current_zone))
            write_status(current_combat_state, current_enemy_name, current_zone)
        end
    end)
end)

-- Periodic monitor (Async loop only checks integer array num; NEVER accesses UObject actor pointers)
LoopAsync(1000, function()
    local is_in_combat = false
    local bm = FindFirstOf("AC_jRPG_BattleManager_C")
    if bm and bm:IsValid() then
        if bm.Enemies and bm.Enemies:IsValid() then
            local count = bm.Enemies:GetArrayNum()
            if count > 0 then
                is_in_combat = true
            end
        end
    end

    if is_in_combat ~= current_combat_state then
        current_combat_state = is_in_combat
        if current_combat_state then
            print("[Expedition33RPC] Combat started! Querying enemies on Game Thread...\n")
            ExecuteInGameThread(function()
                local summary = inspect_active_enemies()
                if summary ~= "" then
                    current_enemy_name = summary
                    print(string.format("[Expedition33RPC] Enemies found: '%s'\n", current_enemy_name))
                end
                write_status(true, current_enemy_name, current_zone)
            end)
        else
            print("[Expedition33RPC] Combat ended!\n")
            current_enemy_name = ""
            write_status(false, "", current_zone)
        end
    else
        -- While in combat, periodically re-check enemies on Game Thread (every 3 seconds)
        if current_combat_state then
            tick_counter = tick_counter + 1
            if tick_counter % 3 == 0 then
                ExecuteInGameThread(function()
                    local summary = inspect_active_enemies()
                    if summary ~= "" and summary ~= current_enemy_name then
                        current_enemy_name = summary
                        print(string.format("[Expedition33RPC] Enemies updated: '%s'\n", current_enemy_name))
                        write_status(true, current_enemy_name, current_zone)
                    end
                end)
            end
        end
    end

    -- During exploration, periodically update zone on Game Thread
    if not current_combat_state then
        tick_counter = tick_counter + 1
        if tick_counter % 3 == 0 then
            ExecuteInGameThread(function()
                local z = resolve_dynamic_screen_zone()
                local cp = resolve_dynamic_checkpoint()
                local changed = false
                if z and z ~= "" and z ~= current_zone then
                    current_zone = z
                    changed = true
                    print(string.format("[Expedition33RPC] Zone dynamically updated to: '%s'\n", current_zone))
                end
                if cp and cp ~= "" and cp ~= current_checkpoint then
                    current_checkpoint = cp
                    changed = true
                    print(string.format("[Expedition33RPC] Checkpoint dynamically updated to: '%s'\n", current_checkpoint))
                end
                if changed then
                    write_status(false, "", current_zone, current_checkpoint)
                end
            end)
        end
    end

    return false -- repeat every 1000ms
end)
