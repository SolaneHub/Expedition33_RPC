print("[Expedition33RPC] Discord Rich Presence Bridge Mod Loaded!\n")

local temp_dir = os.getenv("TEMP") or "C:\\Windows\\Temp"
local status_path = temp_dir .. "\\expedition33_status.json"
local tmp_path = status_path .. ".tmp"

local current_combat_state = false
local current_enemy_name = ""

local function clean_enemy_name(raw)
    if not raw or raw == "" then return "" end

    local name = raw
    -- Strip path or prefix if full object path (e.g. "BP_Enemy_Francois_C /Game/Maps/...")
    local space_idx = string.find(name, " ")
    if space_idx then
        name = string.sub(name, 1, space_idx - 1)
    end
    local dot_idx = string.find(name, "%.")
    if dot_idx then
        name = string.sub(name, dot_idx + 1)
    end

    -- Strip Unreal class and instance suffixes (_C_12345, _C, _1, _0, etc.)
    name = string.gsub(name, "_C_%d+", "")
    name = string.gsub(name, "_C$", "")
    name = string.gsub(name, "_%d+$", "")

    -- Strip common prefixes
    local prefixes = {
        "BP_jRPG_Enemy_Battle_",
        "BP_jRPG_Enemy_",
        "BP_jRPG_Boss_",
        "BP_Enemy_Battle_",
        "BP_Enemy_",
        "BP_Boss_",
        "BP_Minion_",
        "BP_",
        "Default__",
    }
    for _, prefix in ipairs(prefixes) do
        if string.sub(name, 1, #prefix) == prefix then
            name = string.sub(name, #prefix + 1)
            break
        end
    end

    -- Strip variant letter suffix (e.g. _A, _B) and trailing digits
    name = string.gsub(name, "_[A-Za-z]$", "")
    name = string.gsub(name, "_%d+$", "")

    -- Replace underscores with space
    name = string.gsub(name, "_", " ")

    -- Insert spaces before capitals for PascalCase (e.g. DualBlade -> Dual Blade)
    name = string.gsub(name, "(%l)(%u)", "%1 %2")
    name = string.gsub(name, "(%u)(%u%l)", "%1 %2")

    -- Trim whitespace
    name = string.match(name, "^%s*(.-)%s*$") or name

    -- Known special boss / enemy translations
    local special_names = {
        ["Paintress"] = "La Pittrice",
        ["Boss Paintress"] = "La Pittrice",
        ["Verso"] = "Verso",
        ["Francois"] = "Francois",
        ["Goblu"] = "Goblu",
    }
    if special_names[name] then
        name = special_names[name]
    end

    return name
end

local function get_actor_name(actor)
    if not actor then return "" end

    local name = ""
    local text_props = {"CharacterName", "EnemyName", "DisplayName", "Name"}

    -- 1. Try Actor direct properties
    for _, prop in ipairs(text_props) do
        pcall(function()
            local val = actor[prop]
            if val then
                if type(val.ToString) == "function" then
                    local s = val:ToString()
                    if s and s ~= "" and s ~= "None" then
                        name = s
                    end
                elseif type(val) == "string" and val ~= "" and val ~= "None" then
                    name = val
                end
            end
        end)
        if name ~= "" then break end
    end

    -- 2. Try BattleStats component
    if name == "" then
        pcall(function()
            local stats = actor.BattleStats or actor.CharacterBattleStats or actor.Stats
            if stats and stats:IsValid() then
                for _, prop in ipairs(text_props) do
                    local val = stats[prop]
                    if val then
                        if type(val.ToString) == "function" then
                            local s = val:ToString()
                            if s and s ~= "" and s ~= "None" then
                                name = s
                                break
                            end
                        elseif type(val) == "string" and val ~= "" and val ~= "None" then
                            name = val
                            break
                        end
                    end
                end
            end
        end)
    end

    -- 3. Fallback to FName
    if name == "" then
        pcall(function()
            local fname = actor:GetFName():ToString()
            if fname and fname ~= "" and fname ~= "None" then
                name = clean_enemy_name(fname)
            end
        end)
    end

    -- 4. Fallback to FullName
    if name == "" then
        pcall(function()
            local fullname = actor:GetFullName()
            if fullname and fullname ~= "" then
                name = clean_enemy_name(fullname)
            end
        end)
    end

    return name
end

local function format_enemy_summary(enemy_list)
    if not enemy_list or #enemy_list == 0 then
        return ""
    end

    local counts = {}
    local order = {}
    for _, name in ipairs(enemy_list) do
        if name and name ~= "" then
            if not counts[name] then
                counts[name] = 0
                table.insert(order, name)
            end
            counts[name] = counts[name] + 1
        end
    end

    if #order == 0 then
        return ""
    end

    local parts = {}
    for _, name in ipairs(order) do
        local c = counts[name]
        if c > 1 then
            table.insert(parts, string.format("%s x%d", name, c))
        else
            table.insert(parts, name)
        end
    end

    local summary = table.concat(parts, ", ")
    if #summary > 50 then
        if #order > 1 then
            local first = parts[1]
            local remaining = 0
            for i = 2, #order do
                remaining = remaining + counts[order[i]]
            end
            summary = string.format("%s (+%d)", first, remaining)
        else
            summary = string.sub(summary, 1, 47) .. "..."
        end
    end

    return summary
end

local function write_status(in_combat, enemy_name)
    enemy_name = enemy_name or ""
    local escaped_enemy = string.gsub(enemy_name, '"', '\\"')
    local f = io.open(tmp_path, "w")
    if f then
        f:write(string.format('{"in_combat": %s, "enemy_name": "%s", "timestamp": %d}\n',
            in_combat and "true" or "false",
            escaped_enemy,
            os.time()))
        f:close()
        os.remove(status_path)
        os.rename(tmp_path, status_path)
    end
end

-- Write initial exploration status
write_status(false, "")

local fn_onBattleDependenciesLoaded = "/Game/jRPGTemplate/Blueprints/Components/AC_jRPG_BattleManager.AC_jRPG_BattleManager_C:OnBattleDependenciesFullyLoaded"

-- Hook 1: Immediate trigger when battle starts
local preId, postId = -1, -1
preId, postId = RegisterHook("/Script/Engine.PlayerController:ClientRestart", function()
    RegisterHook(fn_onBattleDependenciesLoaded, function()
        print("[Expedition33RPC] Battle dependencies loaded -> In Combat!\n")
        current_combat_state = true
        write_status(true, "")
    end)
    UnregisterHook("/Script/Engine.PlayerController:ClientRestart", preId, postId)
end)

-- Hook 2: Periodic monitor for active battle manager, enemy details, and battle conclusion
LoopAsync(1000, function()
    local is_in_combat = false
    local enemy_summary = ""
    local bm = FindFirstOf("AC_jRPG_BattleManager_C")
    if bm and bm:IsValid() then
        if bm.Enemies and bm.Enemies:IsValid() then
            local count = 0
            pcall(function() count = bm.Enemies:GetArrayNum() end)
            if count == 0 then
                pcall(function() count = #bm.Enemies end)
            end

            if count > 0 then
                is_in_combat = true
                local enemy_names = {}

                -- Method 1: ForEach
                if type(bm.Enemies.ForEach) == "function" then
                    pcall(function()
                        bm.Enemies:ForEach(function(index, elem)
                            local actor = elem
                            if actor and type(actor.get) == "function" then
                                local ok, unwrapped = pcall(function() return actor:get() end)
                                if ok and unwrapped then actor = unwrapped end
                            end
                            if actor and actor.IsValid and actor:IsValid() then
                                local ename = get_actor_name(actor)
                                if ename ~= "" then
                                    table.insert(enemy_names, ename)
                                end
                            end
                        end)
                    end)
                end

                -- Method 2: Indexing fallback
                if #enemy_names == 0 then
                    for i = 1, count do
                        pcall(function()
                            local elem = bm.Enemies[i]
                            local actor = elem
                            if actor and type(actor.get) == "function" then
                                local ok, unwrapped = pcall(function() return actor:get() end)
                                if ok and unwrapped then actor = unwrapped end
                            end
                            if actor and actor.IsValid and actor:IsValid() then
                                local ename = get_actor_name(actor)
                                if ename ~= "" then
                                    table.insert(enemy_names, ename)
                                end
                            end
                        end)
                    end
                end

                enemy_summary = format_enemy_summary(enemy_names)
            end
        end
    end

    if is_in_combat ~= current_combat_state or (is_in_combat and enemy_summary ~= current_enemy_name) then
        current_combat_state = is_in_combat
        current_enemy_name = enemy_summary
        write_status(current_combat_state, current_enemy_name)
        print(string.format("[Expedition33RPC] Combat: %s, Enemy: '%s'\n", tostring(current_combat_state), current_enemy_name))
    end

    return false -- repeat every 1000ms
end)
