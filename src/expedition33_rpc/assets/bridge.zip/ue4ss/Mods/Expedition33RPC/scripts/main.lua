print("[Expedition33RPC] Discord Rich Presence Bridge Mod Loaded!\n")

local temp_dir = os.getenv("TEMP") or "C:\\Windows\\Temp"
local status_path = temp_dir .. "\\expedition33_status.json"
local tmp_path = status_path .. ".tmp"

local current_combat_state = false

local function write_status(in_combat)
    local f = io.open(tmp_path, "w")
    if f then
        f:write(string.format('{"in_combat": %s, "timestamp": %d}\n', in_combat and "true" or "false", os.time()))
        f:close()
        os.remove(status_path)
        os.rename(tmp_path, status_path)
    end
end

-- Write initial exploration status
write_status(false)

local fn_onBattleDependenciesLoaded = "/Game/jRPGTemplate/Blueprints/Components/AC_jRPG_BattleManager.AC_jRPG_BattleManager_C:OnBattleDependenciesFullyLoaded"

-- Hook 1: Immediate trigger when battle starts
local preId, postId = -1, -1
preId, postId = RegisterHook("/Script/Engine.PlayerController:ClientRestart", function()
    RegisterHook(fn_onBattleDependenciesLoaded, function()
        print("[Expedition33RPC] Battle dependencies loaded -> In Combat!\n")
        current_combat_state = true
        write_status(true)
    end)
    UnregisterHook("/Script/Engine.PlayerController:ClientRestart", preId, postId)
end)

-- Hook 2: Periodic monitor for active battle manager and battle conclusion
LoopAsync(1000, function()
    local is_in_combat = false
    local bm = FindFirstOf("AC_jRPG_BattleManager_C")
    if bm and bm:IsValid() then
        if bm.Enemies and bm.Enemies:IsValid() then
            local count = bm.Enemies:GetArrayNum()
            if count > 0 then
                is_in_combat = true
            end
        end
    end

    if is_in_combat ~= current_combat_state then
        current_combat_state = is_in_combat
        write_status(current_combat_state)
        print(string.format("[Expedition33RPC] Combat state transitioned to: %s\n", tostring(current_combat_state)))
    end

    return false -- repeat every 1000ms
end)
