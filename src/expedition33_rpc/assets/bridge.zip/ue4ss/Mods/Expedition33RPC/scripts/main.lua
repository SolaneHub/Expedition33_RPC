print("[Expedition33RPC] Discord Rich Presence Bridge Mod Loaded!\n")

local temp_dir = os.getenv("TEMP") or "C:\\Windows\\Temp"
local status_path = temp_dir .. "\\expedition33_status.json"
local tmp_path = status_path .. ".tmp"

local current_combat_state = false
local current_enemy_name = ""
local current_enemies = {}
local current_tower_floor = nil
local current_tower_trial = nil
local current_zone = ""
local current_checkpoint = ""
local tick_counter = 0
local token_history_path = temp_dir .. "\\expedition33_token_history.txt"
local seen_tokens = {}

local function record_token(category, name, extra)
    if not name or name == "" or name == "None" then return end
    local key = category .. ":" .. name
    if not seen_tokens[key] then
        seen_tokens[key] = true
        local extra_str = (extra and extra ~= "") and (" | " .. tostring(extra)) or ""
        local line = string.format("[%s] [%s] %s%s\n", os.date("%H:%M:%S"), category, name, extra_str)
        print("[Expedition33RPC] TOKEN DISCOVERED: " .. line)
        local f = io.open(token_history_path, "a")
        if f then
            f:write(line)
            f:close()
        end
    end
end

local current_raw_zone = ""
local current_raw_level = ""
local current_world_path = ""

local function clean_enemy_bp_name(raw)
    if not raw or raw == "" then return "" end

    local name = raw
    name = string.gsub(name, "_C_%d+", "")
    name = string.gsub(name, "_C$", "")
    name = string.gsub(name, "_%d+$", "")

    local prefixes = {
        "BP_Enemy_Battle_",
        "BP_EnemyBattle_",
        "BP_jRPG_EnemyBattle_",
        "BP_jRPG_EnemyWorld_",
        "BP_jRPG_Enemy_",
        "BP_jRPG_Boss_",
        "BP_EnemyWorld_",
        "BP_Enemy_",
        "BP_Boss_",
        "BP_Minion_",
        "BP_",
        "Default__",
    }
    for _, p in ipairs(prefixes) do
        if string.sub(name, 1, #p) == p then
            name = string.sub(name, #p + 1)
            break
        end
    end

    name = string.gsub(name, "_[A-Za-z]$", "")
    name = string.gsub(name, "_%d+$", "")
    name = string.gsub(name, "_", " ")
    name = string.gsub(name, "(%l)(%u)", "%1 %2")
    name = string.gsub(name, "(%u)(%u%l)", "%1 %2")
    name = string.gsub(name, "Chromatic", "Alpha")
    name = string.gsub(name, "chromatic", "Alpha")

    return (string.match(name, "^%s*(.-)%s*$") or name)
end

local function clean_level_name(raw)
    if not raw or raw == "" then return "" end

    local name = raw
    name = string.gsub(name, "_C$", "")
    name = string.gsub(name, "_%d+$", "")

    local prefixes = {
        "Level_Side_",
        "Level_Main_",
        "Level_Small_",
        "Level_WorldMap_",
        "SideLevel_",
        "MainLevel_",
        "SmallLevel_",
        "Level_",
    }
    for _, p in ipairs(prefixes) do
        if string.sub(name, 1, #p) == p then
            name = string.sub(name, #p + 1)
            break
        end
    end

    name = string.gsub(name, "_V%d+$", "")
    name = string.gsub(name, "_", " ")
    name = string.gsub(name, "(%l)(%u)", "%1 %2")
    name = string.gsub(name, "(%u)(%u%l)", "%1 %2")
    name = string.match(name, "^%s*(.-)%s*$") or name
    if name == "Main" or string.find(string.lower(raw), "worldmap") then
        return "The Continent"
    end
    if string.find(string.lower(raw), "mainmenu") then
        return "Level_MainMenu"
    end
    return name
end

local function format_enemy_summary(enemy_list)
    if not enemy_list or #enemy_list == 0 then
        return ""
    end

    local counts = {}
    local order = {}
    for _, name in ipairs(enemy_list) do
        if name and name ~= "" then
            if not counts[name] then
                counts[name] = 0
                table.insert(order, name)
            end
            counts[name] = counts[name] + 1
        end
    end

    if #order == 0 then
        return ""
    end

    local parts = {}
    for _, name in ipairs(order) do
        local c = counts[name]
        if c > 1 then
            table.insert(parts, string.format("%s x%d", name, c))
        else
            table.insert(parts, name)
        end
    end

    local summary = table.concat(parts, ", ")
    if #summary > 50 then
        if #order > 1 then
            local first = parts[1]
            local remaining = 0
            for i = 2, #order do
                remaining = remaining + counts[order[i]]
            end
            summary = string.format("%s (+%d)", first, remaining)
        else
            summary = string.sub(summary, 1, 47) .. "..."
        end
    end

    return summary
end

local function json_escape(s)
    if not s then return "" end
    s = string.gsub(s, "\\", "\\\\")
    s = string.gsub(s, '"', '\\"')
    s = string.gsub(s, "\n", "\\n")
    s = string.gsub(s, "\r", "\\r")
    s = string.gsub(s, "\t", "\\t")
    return s
end

local function write_status(in_combat, enemy_name, zone, checkpoint, enemies, tower_floor, tower_trial, raw_zone_in, raw_level_in, world_path_in)
    enemy_name = enemy_name or current_enemy_name or ""
    zone = zone or current_zone or ""
    enemies = enemies or current_enemies or {}
    local raw_z = raw_zone_in or current_raw_zone or zone or ""
    local raw_l = raw_level_in or current_raw_level or ""
    local w_path = world_path_in or current_world_path or ""
    if tower_floor == nil then tower_floor = current_tower_floor end
    if tower_trial == nil then tower_trial = current_tower_trial end

    local is_continent = (zone == "The Continent" or string.find(string.lower(zone), "continent"))
    local is_menu = (zone == "Level_MainMenu" or string.find(string.lower(zone), "mainmenu") or (raw_z ~= "" and string.find(string.lower(raw_z), "mainmenu")))

    if is_continent or is_menu then
        checkpoint = ""
        current_checkpoint = ""
    else
        if checkpoint == nil then
            checkpoint = current_checkpoint or ""
        end
    end

    local escaped_enemy = json_escape(enemy_name)
    local escaped_zone = json_escape(zone)
    local escaped_raw_zone = json_escape(raw_z)
    local escaped_raw_level = json_escape(raw_l)
    local escaped_world_path = json_escape(w_path)
    local escaped_checkpoint = json_escape(checkpoint)

    local enemy_items = {}
    for _, en in ipairs(enemies) do
        if en and en ~= "" then
            table.insert(enemy_items, string.format('"%s"', json_escape(en)))
        end
    end
    local enemies_json = "[" .. table.concat(enemy_items, ", ") .. "]"

    local floor_json = "null"
    if type(tower_floor) == "number" then
        floor_json = string.format("%d", tower_floor)
    end

    local trial_json = "null"
    if type(tower_trial) == "string" and tower_trial ~= "" then
        trial_json = string.format('"%s"', json_escape(tower_trial))
    elseif type(tower_trial) == "number" then
        trial_json = string.format("%d", tower_trial)
    elseif type(tower_trial) == "table" and tower_trial[1] and tower_trial[2] then
        trial_json = string.format("[%d, %d]", tower_trial[1], tower_trial[2])
end

    local payload = string.format(
        '{"in_combat": %s, "enemy_name": "%s", "enemies": %s, "zone": "%s", "raw_zone": "%s", "raw_level": "%s", "world_path": "%s", "checkpoint": "%s", "floor": %s, "tower_floor": %s, "tower_trial": %s, "timestamp": %d}\n',
        in_combat and "true" or "false",
        escaped_enemy,
        enemies_json,
        escaped_zone,
        escaped_raw_zone,
        escaped_raw_level,
        escaped_world_path,
        escaped_checkpoint,
        floor_json,
        floor_json,
        trial_json,
        os.time()
    )

    local f = io.open(tmp_path, "w")
    if f then
        f:write(payload)
        f:close()

        local renamed = false
        for _ = 1, 3 do
            os.remove(status_path)
            if os.rename(tmp_path, status_path) then
                renamed = true
                break
            end
        end

        if not renamed then
            local dst = io.open(status_path, "w")
            if dst then
                dst:write(payload)
                dst:close()
            end
            os.remove(tmp_path)
        end
    end
end

-- Scan UMG widget properties for on-screen text
local function scan_widget_text(w)
    if not w or not w:IsValid() then return nil end

    -- 1. Try known property names first
    local candidate_props = {
        "LevelName", "Text_LevelName", "TextBlock_LevelName",
        "LevelTitle", "Text_LevelTitle", "TextBlock_LevelTitle",
        "ZoneName", "Text_ZoneName", "CurrentLevel", "LevelText",
        "Title", "Text_Title", "Name", "Text_Name"
    }
    for _, pname in ipairs(candidate_props) do
        local ok, val = pcall(function() return w[pname] end)
        if ok and val then
            local ok_gt, txt = pcall(function() return val:GetText():ToString() end)
            if ok_gt and txt and txt ~= "" and txt ~= "None" and not string.find(txt, "<") and #txt > 1 and #txt < 60 then
                return txt
            end
            local ok_ts, s = pcall(function() return val:ToString() end)
            if ok_ts and s and s ~= "" and s ~= "None" and not string.find(s, "<") and #s > 1 and #s < 60 then
                if not string.find(s, "/") and not string.find(s, "BP_") and not string.find(s, "_C") then
                    return s
                end
            end
        end
    end

    -- 2. Reflection scan on PropertyLink
    local ok_cls, cls = pcall(function() return w:GetClass() end)
    if ok_cls and cls and cls:IsValid() then
        local prop = cls.PropertyLink
        while prop and prop:IsValid() do
            local pname = prop:GetFName():ToString()
            if string.find(pname, "Name") or string.find(pname, "Title") or string.find(pname, "Text") or string.find(pname, "Zone") then
                local ok_v, val = pcall(function() return w[pname] end)
                if ok_v and val then
                    local ok_gt, txt = pcall(function() return val:GetText():ToString() end)
                    if ok_gt and txt and txt ~= "" and txt ~= "None" and not string.find(txt, "<") and #txt > 1 and #txt < 60 then
                        return txt
                    end
                    local ok_ts, s = pcall(function() return val:ToString() end)
                    if ok_ts and s and s ~= "" and s ~= "None" and not string.find(s, "<") and #s > 1 and #s < 60 then
                        if not string.find(s, "/") and not string.find(s, "BP_") and not string.find(s, "_C") then
                            return s
                        end
                    end
                end
            end
            prop = prop.PropertyLinkNext
        end
    end

    return nil
end

-- Zone resolution on Game Thread
local function resolve_dynamic_screen_zone()
    local zone_found = nil
    local raw_level_found = ""
    local world_path_found = ""

    -- 1. Try to read from active on-screen HUD widgets
    local widget_classes = {
        "WBP_LevelNameWidget_C",
        "WBP_WorldMapLevelNameContainer_C",
        "WBP_HUD_LevelNameAnnounce_C",
        "WBP_HUD_LevelNameAnnounceQueue_C",
        "WBP_Exploration_HUD_C",
        "WBP_FlyMode_C",
    }
    for _, wclass in ipairs(widget_classes) do
        local widgets = nil
        pcall(function() widgets = FindAllOf(wclass) end)
        if widgets then
            for _, w in ipairs(widgets) do
                if w and w:IsValid() then
                    local txt = scan_widget_text(w)
                    if txt and txt ~= "" then
                        zone_found = txt
                        record_token("HUD_WIDGET_ZONE", txt, wclass)
                        print(string.format("[Expedition33RPC] Dynamic Zone from %s: '%s'\n", wclass, zone_found))
                        break
                    end
                end
            end
        end
        if zone_found then break end
    end

    -- 2. Inspect UWorld & Levels
    local ok_w, err_w = pcall(function()
        local world = nil
        pcall(function()
            local gi = FindFirstOf("GameInstance")
            if gi and gi:IsValid() then
                local w = gi:GetWorld()
                if w and w:IsValid() then world = w end
            end
        end)
        if not world then
            pcall(function()
                local pc = FindFirstOf("PlayerController")
                if pc and pc:IsValid() then
                    local w = pc:GetWorld()
                    if w and w:IsValid() then world = w end
                end
            end)
        end
        if not world then
            pcall(function()
                local eng = FindFirstOf("Engine")
                if eng and eng:IsValid() and eng.GameViewport and eng.GameViewport:IsValid() then
                    local w = eng.GameViewport:GetWorld()
                    if w and w:IsValid() then world = w end
                end
            end)
        end

        if world and world:IsValid() then
            pcall(function()
                local wpath = world:GetPathName()
                if wpath and wpath ~= "" and wpath ~= "None" then
                    world_path_found = tostring(wpath)
                    record_token("WORLD_PATH", world_path_found)
                end
            end)

            pcall(function()
                local statics = StaticFindObject("/Script/Engine.Default__GameplayStatics")
                if statics and statics:IsValid() and type(statics.GetCurrentLevelName) == "function" then
                    local lvl_stripped = statics:GetCurrentLevelName(world, true)
                    if lvl_stripped then
                        local s = lvl_stripped:ToString()
                        if s and s ~= "" and s ~= "None" then
                            raw_level_found = s
                            record_token("LEVEL_NAME_STRIPPED", s)
                        end
                    end
                    local lvl_raw = statics:GetCurrentLevelName(world, false)
                    if lvl_raw then
                        local s = lvl_raw:ToString()
                        if s and s ~= "" and s ~= "None" then
                            record_token("LEVEL_NAME_RAW", s)
                        end
                    end
                end
            end)

            pcall(function()
                if raw_level_found == "" then
                    local plevel = world.PersistentLevel
                    if plevel and plevel:IsValid() then
                        local pouter = plevel:GetOuter()
                        if pouter and pouter:IsValid() then
                            local s = pouter:GetFName():ToString()
                            if s and s ~= "" and s ~= "None" then
                                raw_level_found = s
                                record_token("PERSISTENT_LEVEL_OUTER", s)
                            end
                        end
                    end
                end
            end)

            pcall(function()
                if world.StreamingLevels and world.StreamingLevels:IsValid() then
                    local sl_count = world.StreamingLevels:GetArrayNum()
                    for i = 1, sl_count do
                        local sl = world.StreamingLevels[i]
                        if sl and sl:IsValid() then
                            record_token("STREAMING_LEVEL", sl:GetFName():ToString())
                        end
                    end
                end
            end)
        end
    end)
    if not ok_w then
        print(string.format("[Expedition33RPC] World resolution error: %s\n", tostring(err_w)))
    end

    -- 3. Discover menu & UI widgets
    pcall(function()
        local all_widgets = FindAllOf("UserWidget")
        if all_widgets then
            for _, w in ipairs(all_widgets) do
                if w and w:IsValid() then
                    local cname = w:GetClass():GetFName():ToString()
                    if string.find(cname, "Menu") or string.find(cname, "Title") or string.find(cname, "Boot") or string.find(cname, "Intro") or string.find(cname, "Splash") or string.find(cname, "Screen") or string.find(cname, "Save") or string.find(cname, "Loading") or string.find(cname, "FrontEnd") or string.find(cname, "Frontend") then
                        record_token("MENU_WIDGET", cname)
                    end
                end
            end
        end
    end)

    -- 4. Check if we are in Main Menu widgets
    local is_menu_active = false
    pcall(function()
        local mm = FindFirstOf("WBP_MM_MainMenu_C")
        if mm and mm:IsValid() then is_menu_active = true end
        if not is_menu_active then
            local ts = FindFirstOf("WBP_MM_TitleScreen_C")
            if ts and ts:IsValid() then is_menu_active = true end
        end
        if not is_menu_active then
            local ls = FindFirstOf("WBP_MM_LoadScreen_C")
            if ls and ls:IsValid() then is_menu_active = true end
        end
    end)
    if is_menu_active then
        zone_found = "Level_MainMenu"
        if raw_level_found == "" then
            raw_level_found = "Level_MainMenu"
        end
    end

    if not zone_found and raw_level_found ~= "" then
        zone_found = clean_level_name(raw_level_found)
    end

    current_raw_level = raw_level_found
    current_raw_zone = raw_level_found
    current_world_path = world_path_found

    return zone_found, raw_level_found, world_path_found
end

-- Checkpoint / SavePoint resolution on Game Thread
local function resolve_dynamic_checkpoint()
    local cp = nil
    pcall(function()
        local menu = FindFirstOf("WBP_SavePointMenu_C")
        if menu and menu:IsValid() then
            local is_visible = true
            pcall(function()
                if type(menu.IsVisible) == "function" then
                    is_visible = menu:IsVisible()
                elseif type(menu.GetVisibility) == "function" then
                    local v = menu:GetVisibility()
                    if v ~= 0 and v ~= 4 then
                        is_visible = false
                    end
                end
            end)
            if not is_visible then
                return nil
            end

            local candidate_names = {
                "Text_Subzone", "Text_SubzoneName", "Text_Checkpoint",
                "Text_AreaName", "Text_Location", "SubzoneName",
                "Text_Zone", "ZoneText", "SubzoneText", "Text_SavePointName"
            }
            for _, name in ipairs(candidate_names) do
                local ok, prop = pcall(function() return menu[name] end)
                if ok and prop and prop:IsValid() then
                    local ok_gt, t = pcall(function() return prop:GetText():ToString() end)
                    if ok_gt and t and t ~= "" and t ~= "None" and not string.find(t, "<") and #t > 1 and #t < 60 then
                        cp = t
                        break
                    end
                end
            end

            -- Reflection fallback on menu widget properties
            if not cp then
                local ok_cls, cls = pcall(function() return menu:GetClass() end)
                if ok_cls and cls and cls:IsValid() then
                    local prop = cls.PropertyLink
                    while prop and prop:IsValid() do
                        local pname = prop:GetFName():ToString()
                        if string.find(pname, "Checkpoint") or string.find(pname, "Subzone") or string.find(pname, "Location") or string.find(pname, "SavePoint") or string.find(pname, "Flag") or string.find(pname, "Area") then
                            local ok_v, val = pcall(function() return menu[pname] end)
                            if ok_v and val then
                                local ok_gt, txt = pcall(function() return val:GetText():ToString() end)
                                if ok_gt and txt and txt ~= "" and txt ~= "None" and not string.find(txt, "<") and #txt > 1 and #txt < 60 then
                                    cp = txt
                                    break
                                end
                                local ok_ts, s = pcall(function() return val:ToString() end)
                                if ok_ts and s and s ~= "" and s ~= "None" and not string.find(s, "<") and #s > 1 and #s < 60 then
                                    if not string.find(s, "/") and not string.find(s, "BP_") and not string.find(s, "_C") then
                                        cp = s
                                        break
                                    end
                                end
                            end
                        end
                        prop = prop.PropertyLinkNext
                    end
                end
            end
        end
    end)
    return cp
end

-- Inspect active enemies on Game Thread
local function inspect_active_enemies()
    local enemy_names = {}
    local bm = FindFirstOf("AC_jRPG_BattleManager_C")
    if not bm or not bm:IsValid() then return "" end
    if not bm.Enemies or not bm.Enemies:IsValid() then return "" end

    local count = bm.Enemies:GetArrayNum()
    for i = 1, count do
        pcall(function()
            local elem = bm.Enemies[i]
            local actor = elem
            if actor and type(actor.get) == "function" then
                actor = actor:get()
            end
            if actor and actor:IsValid() then
                local ename = ""
                -- 1. Try CharacterName (FText) if valid text
                pcall(function()
                    if actor.CharacterName and type(actor.CharacterName.ToString) == "function" then
                        local s = actor.CharacterName:ToString()
                        if s and s ~= "" and s ~= "None" and not string.find(s, "<") and not string.find(s, "UObject:") and not string.find(s, "0x") and #s > 1 and #s < 50 then
                            ename = s
                        end
                    end
                end)

                -- 2. Fallback to clean blueprint name (class first, then actor FName)
                if ename == "" then
                    pcall(function()
                        local cls = actor:GetClass()
                        if cls and cls:IsValid() then
                            local raw = cls:GetFName():ToString()
                            ename = clean_enemy_bp_name(raw)
                        end
                    end)
                end

                if ename == "" then
                    pcall(function()
                        local raw = actor:GetFName():ToString()
                        ename = clean_enemy_bp_name(raw)
                    end)
                end

                if ename ~= "" and ename ~= "None" and not string.find(ename, "UObject:") and not string.find(ename, "0x") then
                    ename = string.gsub(ename, "Chromatic", "Alpha")
                    ename = string.gsub(ename, "chromatic", "Alpha")
                    table.insert(enemy_names, ename)
                end
            end
        end)
    end

    return format_enemy_summary(enemy_names), enemy_names
end


local function dump_game_catalog()
    local out_path = temp_dir .. "\\expedition33_catalog_dump.txt"
    local f = io.open(out_path, "w")
    if not f then return end

    f:write("=== ALL LOADED DATA TABLES ===\n")
    pcall(function()
        local dts = FindAllOf("DataTable")
        if dts then
            for _, dt in ipairs(dts) do
                if dt and dt:IsValid() then
                    f:write(string.format("DT: %s | %s\n", dt:GetFName():ToString(), tostring(dt:GetPathName())))
                end
            end
        end
    end)

    f:write("\n=== ALL LOADED STRING TABLES ===\n")
    pcall(function()
        local sts = FindAllOf("StringTable")
        if sts then
            for _, st in ipairs(sts) do
                if st and st:IsValid() then
                    f:write(string.format("ST: %s | %s\n", st:GetFName():ToString(), tostring(st:GetPathName())))
                end
            end
        end
    end)

    f:write("\n=== ALL LOADED WORLDS ===\n")
    pcall(function()
        local ws = FindAllOf("World")
        if ws then
            for _, w in ipairs(ws) do
                if w and w:IsValid() then
                    f:write(string.format("WORLD: %s | %s\n", w:GetFName():ToString(), tostring(w:GetPathName())))
                end
            end
        end
    end)

    f:close()
    print("[Expedition33RPC] Dumped catalog to: " .. out_path .. "\n")
end

-- Initialize initial status on Game Thread
ExecuteInGameThread(function()
    dump_game_catalog()
    current_checkpoint = ""
    local z, rl, wp = resolve_dynamic_screen_zone()
    if z and z ~= "" then
        current_zone = z
        print(string.format("[Expedition33RPC] Initial Zone: '%s' (raw: '%s', path: '%s')\n", current_zone, rl or "", wp or ""))
    end
    write_status(false, "", current_zone, "", nil, nil, nil, rl, rl, wp)
end)

-- Hook map loads to update zone immediately
RegisterLoadMapPostHook(function(Engine, World)
    current_checkpoint = ""
    ExecuteInGameThread(function()
        local z, rl, wp = resolve_dynamic_screen_zone()
        if z and z ~= "" then
            current_zone = z
            print(string.format("[Expedition33RPC] Zone on Map Load: '%s' (raw: '%s', path: '%s')\n", current_zone, rl or "", wp or ""))
            write_status(current_combat_state, current_enemy_name, current_zone, "", nil, nil, nil, rl, rl, wp)
        end
    end)
end)

-- Periodic monitor (Async loop only checks integer array num; NEVER accesses UObject actor pointers)
LoopAsync(1000, function()
    local is_in_combat = false
    local bm = FindFirstOf("AC_jRPG_BattleManager_C")
    if bm and bm:IsValid() then
        if bm.Enemies and bm.Enemies:IsValid() then
            local count = bm.Enemies:GetArrayNum()
            if count > 0 then
                is_in_combat = true
            end
        end
    end

    if is_in_combat ~= current_combat_state then
        current_combat_state = is_in_combat
        if current_combat_state then
            print("[Expedition33RPC] Combat started! Querying enemies on Game Thread...\n")
            ExecuteInGameThread(function()
                local summary, enemies = inspect_active_enemies()
                if summary ~= "" then
                    current_enemy_name = summary
                    current_enemies = enemies or {}
                    print(string.format("[Expedition33RPC] Enemies found: '%s'\n", current_enemy_name))
                end
                write_status(true, current_enemy_name, current_zone, current_checkpoint, current_enemies, current_tower_floor, current_tower_trial)
            end)
        else
            print("[Expedition33RPC] Combat ended!\n")
            current_enemy_name = ""
            current_enemies = {}
            write_status(false, "", current_zone, current_checkpoint, {}, current_tower_floor, current_tower_trial)
        end
    else
        -- While in combat, periodically re-check enemies on Game Thread (every 3 seconds)
        if current_combat_state then
            tick_counter = tick_counter + 1
            if tick_counter % 3 == 0 then
                ExecuteInGameThread(function()
                    local summary, enemies = inspect_active_enemies()
                    if summary ~= "" and summary ~= current_enemy_name then
                        current_enemy_name = summary
                        current_enemies = enemies or {}
                        print(string.format("[Expedition33RPC] Enemies updated: '%s'\n", current_enemy_name))
                        write_status(true, current_enemy_name, current_zone, current_checkpoint, current_enemies, current_tower_floor, current_tower_trial)
                    end
                end)
            end
        end
    end

    -- During exploration, periodically update zone on Game Thread
    if not current_combat_state then
        tick_counter = tick_counter + 1
        if tick_counter % 2 == 0 then
            ExecuteInGameThread(function()
                local z, rl, wp = resolve_dynamic_screen_zone()
                local cp = resolve_dynamic_checkpoint()
                local changed = false
                if z and z ~= "" and z ~= current_zone then
                    current_zone = z
                    current_checkpoint = ""
                    changed = true
                    print(string.format("[Expedition33RPC] Zone dynamically updated to: '%s' (raw: '%s')\n", current_zone, rl or ""))
                end

                local is_continent = (current_zone == "The Continent" or string.find(string.lower(current_zone), "continent"))
                local is_menu = (current_zone == "Level_MainMenu" or (rl and string.find(string.lower(rl), "mainmenu")))
                if is_continent or is_menu then
                    if current_checkpoint ~= "" then
                        current_checkpoint = ""
                        changed = true
                    end
                    cp = nil
                end

                if cp and cp ~= "" and cp ~= current_checkpoint then
                    current_checkpoint = cp
                    changed = true
                    print(string.format("[Expedition33RPC] Checkpoint dynamically updated to: '%s'\n", current_checkpoint))
                end

                write_status(false, "", current_zone, current_checkpoint, {}, current_tower_floor, current_tower_trial, rl, rl, wp)
            end)
        else
            write_status(false, "", current_zone, current_checkpoint, {}, current_tower_floor, current_tower_trial, current_raw_zone, current_raw_level, current_world_path)
        end
    end

    return false -- repeat every 1000ms
end)
